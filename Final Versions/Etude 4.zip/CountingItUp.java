import java.util.ArrayList;
import java.util.Scanner;

/*Input is via 1 line with 2 numbers separated by a space.
  First value is n and second value is k
 */

public class CountingItUp {

    public static void main(String[] args) {
	    CountingItUp main = new CountingItUp();
        ArrayList<String> lines = new ArrayList<>();

	    int n = -1, k = -1;

        Scanner scanner = new Scanner(System.in);

        while(scanner.hasNextLine()) {
            lines.add(scanner.nextLine());
        }

        scanner.close();

        for(String line: lines) {
            String[] split = line.trim().split("\\s+");

            int[] numbers = new int[split.length];

            for (int i = 0; i < split.length; i++) {
                numbers[i] = Integer.parseInt(split[i]);
            }

            main.calculateFactorial(numbers[0], numbers[1]);
        }
    }

    public void calculateFactorial(int n, int k){
        long value = 1;

        int current = -1;
        ArrayList<Integer> factors = new ArrayList<Integer>();

        if(k < (n - k)){
            k = n - k;
        }

        for(int l = 1; l - 1 < n - k; l++){
            factors.add(l);
        }

        for(int i = n; i > k; i--){
            current = i;

            for(int m = factors.size() - 1; m >= 0; m--) {
                int factor = factors.get(m);

                if(current % factor == 0) {
                    current = current / factor;
                    factors.remove(m);
                }

            }

            value *= current;

            for(int m = factors.size() - 1; m >= 0; m--) {
                int factor = factors.get(m);

                if(value % factor == 0) {
                    value = value / factor;
                    factors.remove(m);
                }
            }

        }
        System.out.println((String.valueOf(value)));
    }
}

Spring Han - 4970116
Compile: javac CountingItUp.java
Execute: java CountingItUp < (file of input)

Input: n k
(first value is n followed by a space and then k for each line of input)
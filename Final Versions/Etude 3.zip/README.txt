Spring Han - 4970116
Compile: javac Arithmetic.java
Execute: java Arithmetic < (file of input)
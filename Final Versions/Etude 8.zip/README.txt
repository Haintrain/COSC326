Spring Han - 4970116
Compile: javac BusRoutes.java
Execute: java BusRoutes < (file of routes)
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/*  The program creates two 2d arrays of doubles which sort the locations and distances between points.
    It simply calculates the distance between each point in the array (both [i][k] and [k][i] to save time.
    It then pulls out each row of distances into an ArrayList to sort out the values in order then grabs 12th smallest value (because it has a value of 0.0 for itself).
    It compares this value with the current smallest value and if is smaller replaces it.

    (I only have this comment on here because of the report thing the etude said to have)
 */

public class CordlessPhones {
    private static int numberOfPoints;
    private static double[][] locations;
    private static double[][] distances;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String fileName = input.nextLine();

        input.close();

        File file = new File(fileName);

        try
        {
            Path path = Paths.get(fileName);
            long lineCount = Files.lines(path).count();
            numberOfPoints = (int)lineCount - 1;

            locations = new double[numberOfPoints][2];
            distances = new double[numberOfPoints][numberOfPoints];

            Scanner sc = new Scanner(file);
            sc.nextLine();

            int i = 0;

            while(sc.hasNextLine()){
                String coord[] = sc.nextLine().split(" ");

                locations[i][0] = Double.valueOf(coord[0]);
                locations[i][1] = Double.valueOf(coord[1]);

                i++;
            }

            //System.out.println(Arrays.toString(locations));

            sc.close();
        }
        catch(Exception e){
            System.out.println(e.toString());
        }

        CordlessPhones main = new CordlessPhones();
        main.getNeighbourDistances();

        /*Random r = new Random();
        double randomValue;

        for(int i = 0; i < numberOfPoints; i++){
            randomValue = 50 + (150 - 50) * r.nextDouble();
            locations[i][0] = randomValue;

            randomValue = 50 + (150 - 50) * r.nextDouble();
            locations[i][1] = randomValue;
        }*/
    }

    public void getNeighbourDistances(){
        ArrayList<Double> placeholder = new ArrayList<>();
        double smallestCircle = 10000.0;

        for(int i = 0; i < numberOfPoints; i++){
            for(int k = 0; k < numberOfPoints; k++){
                if(distances[i][k] == 0 && i != k) {
                    distances[i][k] = Math.hypot(locations[i][0] - locations[k][0], locations[i][1] - locations[k][1]);
                }
            }
        }

        for(int i = 0; i < numberOfPoints; i++){
            for(int k = 0; k < numberOfPoints; k++) {
                placeholder.add(distances[i][k]);
            }

            Collections.sort(placeholder);
            if(smallestCircle > placeholder.get(Math.min(12, numberOfPoints - 1))) {
                smallestCircle = placeholder.get(Math.min(12, numberOfPoints - 1));
            }

            placeholder.clear();
        }

        System.out.println(String.valueOf(smallestCircle));
    }
}

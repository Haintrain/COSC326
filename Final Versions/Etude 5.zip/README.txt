Spring Han - 4970116
Compile: javac CordlessPhones.java
Execute: java CordlessPhones < (file input)
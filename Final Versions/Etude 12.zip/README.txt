Spring Han - 4970116
Execute: python DrawBusRoutes.py < (file of routes)
import java.util.ArrayList;
import java.util.Scanner;

public class ManyDates {

    public static void main(String[] args) {
        ManyDates main = new ManyDates();

        ArrayList<String> dates = new ArrayList<>();

        Scanner input = new Scanner(System.in);

        while (input.hasNextLine()){
            dates.add(input.nextLine());
        }

        input.close();

        for(String date: dates) {
            main.checkDates(date);
        }
    }

    public void checkDates(String date){
        String[] parts = date.split("/");
        int[] values = new int[3];
        int[] errors = new int[3];

        for(int i = 0; i < 3; i++){
            values[i] = Integer.parseInt(parts[i]);

            if(values[i] > 3000 || (values[i] < 1753 && values[i] > 100)){
                errorMessage(date, "Invalid: Year out of range.");
                return;
            }
        }



        if(values[0] < 32){
            if(values[1] < 13){ //DD/MM/YY
                if (isValidYear(values[0], values[1], values[2])){
                    validDate(values[0], values[1], values[2], date);
                    return;
                }
            }
            else {
                errors[1]++;
            }

            if(values[2] < 13){ //DD/YY/MM
                if(isValidYear(values[0], values[2], values[1])){
                    validDate(values[0], values[2], values[1], date);
                    return;
                }
            }
            else {
                errors[1]++;
            }
        }
        else{
            errors[0]++;
        }

        if(values[1] < 32) {
            if(values[0] < 13) {
                if(isValidYear(values[1], values[0], values[2])){
                    validDate(values[1], values[0], values[2], date);
                    return;
                }
            }
            else{
                errors[1]++;
            }

            if(values[2] < 13){
                if(isValidYear(values[1], values[2], values[0])){
                    validDate(values[1], values[2], values[0], date);
                    return;
                }
            }
            else {
                errors[1]++;
            }
        }
        else{
            errors[0]++;
        }

        if(values[2] < 32){
            if(values[0] < 13){
                if(isValidYear(values[2], values[0], values[1])){
                    validDate(values[2],values[0],values[1], date);
                    return;
                }
            }
            else {
                errors[1]++;
            }

            if(values[1] < 13){
                if(isValidYear(values[2], values[1], values[0])){
                    validDate(values[2],values[1],values[0], date);
                    return;
                }
            }
            else {
                errors[1]++;
            }
        }
        else{
            errors[0]++;
        }

        if(errors[1] == 6){
            errorMessage(date, "Invalid: Months out of range.");
        }
        else {
            errorMessage(date, "Invalid: Incorrect days and months.");
        }
    }

    public void validDate(int day, int month, int year, String date){
        String currentMonth = "";

        if(year > 49 && year < 100){
            year = 1900 + year;
        }
        else if(year < 50){
            year = 2000 + year;
        }

        switch(month){
            case 1:
                currentMonth = "Jan";
                break;
            case 2:
                currentMonth = "Feb";
                break;
            case 3:
                currentMonth = "Mar";
                break;
            case 4:
                currentMonth = "Apr";
                break;
            case 5:
                currentMonth = "May";
                break;
            case 6:
                currentMonth = "Jun";
                break;
            case 7:
                currentMonth = "Jul";
                break;
            case 8:
                currentMonth = "Aug";
                break;
            case 9:
                currentMonth = "Sep";
                break;
            case 10:
                currentMonth = "Oct";
                break;
            case 11:
                currentMonth = "Nov";
                break;
            case 12:
                currentMonth = "Dec";
                break;
        }

        System.out.println(String.valueOf(day) + " " + currentMonth + " " + String.valueOf(year));
    }

    public boolean isLeapYear(int year){
        if(year > 49 && year < 100) {
            year = 1900 + year;
        }
        else if(year < 50){
            year = 2000 + year;
        }

        if(year % 100 == 0 && year % 400 == 0){
            return true;
        }
        else if (year % 100 == 0){
            return false;
        }
        else if(year % 4 == 0){
            return true;
        }

        return false;
    }

    public boolean isValidYear(int day, int month, int year){
            if(day == 29 && month == 2){
                if(isLeapYear(year)){
                    return true;
                }
                else{
                    return false;
                }
            }
            else if(day == 31){
                if(month == 1 || month == 3 || month == 5 || month == 7 || month == 9 || month == 11){
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                return true;
            }
    }

    public void errorMessage(String date, String message){
        System.out.println(date + " - " + message);
    }
}

Spring Han - 4970116
Compile: javac ManyDates.java
Execute: java ManyDates < (file of dates)
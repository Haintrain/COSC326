Spring Han - 4970116
Compile: javac PokerHands.java
Exectue: java PokerHands < (file of hands)
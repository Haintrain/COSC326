Spring Han - 4970116
Compile: javac QuiltingBee.java
Execute: java QuiltingBee < (file with quilts)
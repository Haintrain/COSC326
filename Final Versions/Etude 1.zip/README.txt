Spring Han - 4970116
Compile: javac EmailAddresses.java
Execute: java EmailAddresses < (file of emails)